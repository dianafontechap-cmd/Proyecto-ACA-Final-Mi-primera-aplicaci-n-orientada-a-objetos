package com.proyecto.excepciones;

/**
 * Excepción personalizada: se lanza cuando se busca un producto
 * cuyo código no existe en el inventario.
 *
 * Hereda de Exception, por eso es una excepción "chequeada":
 * el compilador obliga a manejarla con try-catch o a declararla con throws.
 */
public class ProductoNoEncontradoException extends Exception {

    public ProductoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
