package com.proyecto.modelo;

/**
 * EXTRA — Herencia y polimorfismo.
 *
 * ProductoPerecedero ES UN Producto (extends), pero además tiene
 * fecha de vencimiento. Hereda todos los atributos y métodos de Producto
 * y solo agrega lo que lo hace diferente.
 */
public class ProductoPerecedero extends Producto {

    private String fechaVencimiento;

    public ProductoPerecedero(int codigo, String nombre, String categoria,
                              double precio, int cantidad, String fechaVencimiento) {
        // super(...) llama al constructor de la clase padre (Producto)
        super(codigo, nombre, categoria, precio, cantidad);
        this.fechaVencimiento = fechaVencimiento;
    }

    public String getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(String fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    /**
     * POLIMORFISMO (sobrescritura): este método reemplaza al de Producto.
     * Cuando el Inventario recorre la lista y llama a mostrarInformacion(),
     * Java decide en tiempo de ejecución cuál versión usar según el tipo
     * real del objeto.
     */
    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion(); // reutiliza lo que ya imprime Producto
        System.out.println("Tipo: Perecedero");
        System.out.println("Fecha de vencimiento: " + fechaVencimiento);
    }
}
