package com.proyecto.modelo;

import com.proyecto.excepciones.ProductoNoEncontradoException;

import java.util.ArrayList;

/**
 * Clase CONTENEDORA: el inventario de la tienda.
 *
 * Conceptos de POO aplicados:
 *  - Relación entre clases: un Inventario CONTIENE muchos Producto.
 *  - Lista: ArrayList<Producto> guarda los productos en memoria.
 *  - Recorrido de listas: for-each en mostrarTodos() y buscarPorCodigo().
 *  - Excepción personalizada: buscarPorCodigo() lanza
 *    ProductoNoEncontradoException si el código no existe.
 */
public class Inventario {

    private ArrayList<Producto> productos = new ArrayList<>();

    /**
     * Agrega un producto. No permite códigos repetidos.
     * Como la lista es de tipo Producto, acepta también ProductoPerecedero
     * (porque un ProductoPerecedero ES UN Producto).
     */
    public void agregar(Producto p) {
        if (existeCodigo(p.getCodigo())) {
            throw new IllegalArgumentException(
                    "Ya existe un producto con el código " + p.getCodigo() + ".");
        }
        productos.add(p);
    }

    /**
     * Recorre la lista, muestra cada producto y calcula el valor total.
     * Un solo método resuelve: relación entre clases + recorrido + cálculo.
     */
    public void mostrarTodos() {
        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return;
        }

        double valorTotal = 0;
        for (Producto p : productos) {
            p.mostrarInformacion();   // polimorfismo: cada objeto usa su versión
            System.out.println("---------------------------------");
            valorTotal += p.calcularValor();
        }
        System.out.println("Productos registrados: " + productos.size());
        System.out.println("Valor total del inventario: " + valorTotal);
    }

    /** Busca por código; si no lo encuentra, lanza la excepción personalizada. */
    public Producto buscarPorCodigo(int codigo) throws ProductoNoEncontradoException {
        for (Producto p : productos) {
            if (p.getCodigo() == codigo) {
                return p;
            }
        }
        throw new ProductoNoEncontradoException("El producto no fue encontrado.");
    }

    private boolean existeCodigo(int codigo) {
        for (Producto p : productos) {
            if (p.getCodigo() == codigo) {
                return true;
            }
        }
        return false;
    }
}
