package com.proyecto;

import com.proyecto.excepciones.ProductoNoEncontradoException;
import com.proyecto.modelo.Inventario;
import com.proyecto.modelo.Producto;
import com.proyecto.modelo.ProductoPerecedero;

import java.util.Scanner;

/**
 * Punto de entrada del programa: menú por consola.
 */
public class Main {

    // Scanner: biblioteca estándar de Java para leer desde la consola
    private static Scanner scanner = new Scanner(System.in);
    private static Inventario inventario = new Inventario();

    // ARREGLO simple: categorías disponibles (tamaño fijo, no cambia)
    private static final String[] CATEGORIAS = {"Aseo", "Alimentos", "Tecnología"};

    public static void main(String[] args) {
        int opcion = 0;

        do {
            System.out.println();
            System.out.println("=================================");
            System.out.println("      SISTEMA DE INVENTARIO");
            System.out.println("=================================");
            System.out.println("1. Registrar producto");
            System.out.println("2. Mostrar productos");
            System.out.println("3. Buscar producto por código");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");

            // TRY-CATCH 1 (núcleo): si escriben letras en el menú, no se rompe
            try {
                opcion = Integer.parseInt(scanner.nextLine().trim());

                switch (opcion) {
                    case 1:
                        registrarProducto();
                        break;
                    case 2:
                        System.out.println("----- PRODUCTOS -----");
                        inventario.mostrarTodos();
                        break;
                    case 3:
                        buscarProducto();
                        break;
                    case 4:
                        System.out.println("Saliendo del sistema. ¡Hasta pronto!");
                        break;
                    default:
                        System.out.println("Opción no válida. Elija entre 1 y 4.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un número válido.");
            }

        } while (opcion != 4);

        scanner.close();
    }

    /**
     * Pide los datos y registra el producto.
     *
     * EXTRA — Segundo try-catch: valida números mal escritos, valores
     * negativos, nombre vacío, categoría fuera de rango y código repetido.
     */
    private static void registrarProducto() {
        try {
            System.out.print("Código: ");
            int codigo = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();

            String categoria = elegirCategoria();

            System.out.print("Precio: ");
            double precio = Double.parseDouble(scanner.nextLine().trim());

            System.out.print("Cantidad: ");
            int cantidad = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("¿Es perecedero? (s/n): ");
            String respuesta = scanner.nextLine().trim();

            Producto producto;
            if (respuesta.equalsIgnoreCase("s")) {
                System.out.print("Fecha de vencimiento (dd/mm/aaaa): ");
                String fecha = scanner.nextLine().trim();
                producto = new ProductoPerecedero(codigo, nombre, categoria, precio, cantidad, fecha);
            } else {
                producto = new Producto(codigo, nombre, categoria, precio, cantidad);
            }

            inventario.agregar(producto);
            System.out.println("Producto registrado correctamente.");

        } catch (NumberFormatException e) {
            // Va PRIMERO porque NumberFormatException es hija de IllegalArgumentException
            System.out.println("Error: debe ingresar un número válido. Registro cancelado.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage() + " Registro cancelado.");
        }
    }

    /** Recorre el ARREGLO de categorías y deja escoger una. */
    private static String elegirCategoria() {
        System.out.println("Categorías disponibles:");
        for (int i = 0; i < CATEGORIAS.length; i++) {
            System.out.println("  " + (i + 1) + ". " + CATEGORIAS[i]);
        }
        System.out.print("Seleccione la categoría: ");
        int indice = Integer.parseInt(scanner.nextLine().trim());

        if (indice < 1 || indice > CATEGORIAS.length) {
            throw new IllegalArgumentException("La categoría seleccionada no existe.");
        }
        return CATEGORIAS[indice - 1];
    }

    /** Busca un producto: aquí se maneja la EXCEPCIÓN PERSONALIZADA. */
    private static void buscarProducto() {
        try {
            System.out.print("Ingrese el código: ");
            int codigo = Integer.parseInt(scanner.nextLine().trim());

            Producto p = inventario.buscarPorCodigo(codigo);
            System.out.println("----- PRODUCTO ENCONTRADO -----");
            p.mostrarInformacion();

        } catch (ProductoNoEncontradoException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error: el código debe ser un número.");
        }
    }
}
