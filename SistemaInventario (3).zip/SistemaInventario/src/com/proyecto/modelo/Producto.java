package com.proyecto.modelo;

/**
 * Clase de OBJETO: representa un producto de la tienda.
 *
 * Conceptos de POO aplicados:
 *  - Clase y objeto: cada "new Producto(...)" crea un objeto distinto.
 *  - Encapsulamiento: los atributos son private y solo se accede a ellos
 *    mediante getters y setters.
 *  - Validación en los setters: no se permite precio ni cantidad negativa
 *    (esto alimenta el "segundo try-catch" del Main).
 */
public class Producto {

    // ===== Atributos (private = encapsulamiento) =====
    private int codigo;
    private String nombre;
    private String categoria;
    private double precio;
    private int cantidad;

    // ===== Constructor =====
    public Producto(int codigo, String nombre, String categoria, double precio, int cantidad) {
        this.codigo = codigo;
        this.categoria = categoria;
        // Usamos los setters para que las validaciones se apliquen
        // también al momento de crear el objeto.
        setNombre(nombre);
        setPrecio(precio);
        setCantidad(cantidad);
    }

    // ===== Getters y setters =====
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        this.nombre = nombre.trim();
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo.");
        }
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        if (cantidad < 0) {
            throw new IllegalArgumentException("La cantidad no puede ser negativa.");
        }
        this.cantidad = cantidad;
    }

    // ===== Métodos propios (acciones del objeto) =====

    /** Valor de este producto en inventario = precio x cantidad. */
    public double calcularValor() {
        return precio * cantidad;
    }

    /**
     * Muestra la información del producto.
     * La subclase ProductoPerecedero SOBRESCRIBE este método (polimorfismo).
     */
    public void mostrarInformacion() {
        System.out.println("Código: " + codigo);
        System.out.println("Nombre: " + nombre);
        System.out.println("Categoría: " + categoria);
        System.out.println("Precio: " + precio);
        System.out.println("Cantidad: " + cantidad);
    }
}
