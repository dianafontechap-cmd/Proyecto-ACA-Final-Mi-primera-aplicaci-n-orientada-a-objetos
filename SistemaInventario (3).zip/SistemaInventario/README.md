# Sistema Básico de Inventario

**Proyecto ACA Final — Mi primera aplicación orientada a objetos**
Curso: Programación Orientada a Objetos

**Estudiante:** Diana Marcela Fontecha Patiño

---

## Descripción

Aplicación de consola en Java que simula el inventario de una pequeña tienda. Permite registrar productos, listarlos con el valor total del inventario y buscarlos por código. La información se guarda en memoria (no usa base de datos ni interfaz gráfica).

Además de los productos normales, el sistema maneja **productos perecederos**, que tienen fecha de vencimiento.

## Funcionalidades

| Opción | Acción |
|---|---|
| 1. Registrar producto | Pide código, nombre, categoría, precio, cantidad y si es perecedero (en ese caso pide la fecha de vencimiento). |
| 2. Mostrar productos | Lista todos los productos y calcula el **valor total del inventario** (precio × cantidad). |
| 3. Buscar producto por código | Muestra el producto o un mensaje de error si no existe. |
| 4. Salir | Termina el programa. |

Validaciones incluidas:
- Letras u opciones fuera de rango en el menú.
- Números mal escritos al registrar o buscar.
- Precio o cantidad negativos.
- Nombre vacío.
- Categoría inexistente.
- Código de producto repetido.
- Búsqueda de un producto que no existe (excepción personalizada).

## Clases utilizadas

```
src/
└── com/proyecto/
    ├── Main.java                         → Menú por consola
    ├── modelo/
    │   ├── Producto.java                 → Clase de objeto
    │   ├── ProductoPerecedero.java       → Subclase de Producto (herencia)
    │   └── Inventario.java               → Clase contenedora (ArrayList<Producto>)
    └── excepciones/
        └── ProductoNoEncontradoException.java → Excepción personalizada
```

| Clase | Responsabilidad |
|---|---|
| `Producto` | Representa un producto: código, nombre, categoría, precio y cantidad. Calcula su valor y muestra su información. |
| `ProductoPerecedero` | Hereda de `Producto` y agrega la fecha de vencimiento. Sobrescribe `mostrarInformacion()`. |
| `Inventario` | Guarda los productos en un `ArrayList`, los muestra con el valor total y los busca por código. |
| `ProductoNoEncontradoException` | Se lanza cuando se busca un código que no existe. |
| `Main` | Muestra el menú, lee los datos con `Scanner` y maneja los errores. |

## Conceptos de POO aplicados

| Concepto | Dónde se aplica |
|---|---|
| Clases y objetos | `Producto`, `ProductoPerecedero`, `Inventario`; cada registro crea un objeto nuevo. |
| Atributos y métodos | Atributos de `Producto`; métodos `calcularValor()`, `mostrarInformacion()`, `agregar()`, `buscarPorCodigo()`. |
| Encapsulamiento | Todos los atributos son `private` y se accede por getters/setters. Los setters validan precio, cantidad y nombre. |
| Relación entre clases | `Inventario` contiene muchos `Producto` (composición). |
| Arreglos | `String[] CATEGORIAS` en `Main`, recorrido con `for` para mostrar las categorías. |
| Listas y recorrido | `ArrayList<Producto>` en `Inventario`, recorrido con for-each. |
| Bibliotecas estándar | `java.util.Scanner`, `java.util.ArrayList`. |
| try-catch | En el menú (`NumberFormatException`) y al buscar un producto. |
| Excepción personalizada | `ProductoNoEncontradoException`, lanzada por `Inventario.buscarPorCodigo()`. |
| **Extra:** Herencia | `ProductoPerecedero extends Producto`. |
| **Extra:** Polimorfismo | `ProductoPerecedero` sobrescribe `mostrarInformacion()` con `@Override`; el inventario llama al método correcto según el tipo real del objeto. |
| **Extra:** Segundo try-catch | En `registrarProducto()`: captura números inválidos y valores negativos, nombre vacío, categoría inexistente o código repetido (`IllegalArgumentException`). |
| **Extra:** Paquetes | `com.proyecto.modelo`, `com.proyecto.excepciones` y `Main` en `com.proyecto`. |

## Instrucciones para ejecutar

Requisito: tener instalado el **JDK 11 o superior** (`java -version` para verificarlo).

### Desde la consola (PowerShell o CMD), en la carpeta del proyecto

```bash
# 1. Compilar
javac -encoding UTF-8 -d out src/com/proyecto/*.java src/com/proyecto/modelo/*.java src/com/proyecto/excepciones/*.java

# 2. Ejecutar
java -Dstdout.encoding=UTF-8 -cp out com.proyecto.Main
```

> Si en Windows las tildes se ven raras, ejecute antes `chcp 65001` en la consola.

### Desde un IDE (NetBeans, IntelliJ IDEA, Eclipse o VS Code)

1. Abrir la carpeta del proyecto.
2. Marcar `src` como carpeta de código fuente (si el IDE no lo hace solo).
3. Ejecutar la clase `com.proyecto.Main`.

## Ejemplo de uso

```
=================================
      SISTEMA DE INVENTARIO
=================================
1. Registrar producto
2. Mostrar productos
3. Buscar producto por código
4. Salir
Seleccione una opción: 3
Ingrese el código: 999
Error: El producto no fue encontrado.
```
